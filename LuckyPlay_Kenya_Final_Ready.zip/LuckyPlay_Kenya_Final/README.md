# LuckyPlay Kenya — Final Sandbox Package

This is the prepared LuckyPlay Kenya website plus a server-side Safaricom Daraja B2C sandbox integration scaffold.

## Included
- `index.html` — responsive LuckyPlay Kenya website, games, rewards, wallet and demo withdrawals
- `server.js` — Express server, Daraja OAuth, B2C request and callback endpoints
- `package.json` — Node/Express setup
- `.env.example` — private configuration template
- `render.yaml` — ready-to-use Render Web Service configuration
- `.gitignore` — keeps `.env` and dependencies out of Git

## What is already done
- Responsive LuckyPlay Kenya website
- Demo registration/login and wallet
- Games, daily reward and points
- Transaction history and demo redemption
- Kenyan M-Pesa phone validation
- Points-to-KSh demo conversion
- Server-side Daraja OAuth
- B2C sandbox request endpoint
- ResultURL and QueueTimeOutURL callback endpoints
- Health endpoint for hosting checks
- No Daraja secrets in the browser
- Render configuration prepared

## Only account-specific values left
These must come from your own Daraja account and must **not** be sent to ChatGPT or committed to GitHub:
1. Daraja Consumer Key
2. Daraja Consumer Secret
3. Daraja Initiator Name
4. Daraja Security Credential
5. Daraja B2C sandbox shortcode/test shortcode

On Render, these are entered as private Environment Variables. The app automatically uses Render's public HTTPS address for the callback URLs, so you normally do not need to type callback URLs manually.

## Deploying from GitHub to Render
1. Put this folder's files into your GitHub repository.
2. In Render, create a Web Service from that GitHub repository.
3. Render will use `render.yaml`, `npm install`, and `npm start`.
4. Add the five private Daraja environment variables above.
5. Open `/api/health` on the deployed service and confirm it returns `ok: true`.
6. After the Daraja app has B2C Sandbox enabled, test a sandbox withdrawal.

## Local test
Requires Node.js 18+.

```bash
npm install
cp .env.example .env
npm start
```

Then open `http://localhost:3000`.

## Security
Never put Consumer Secret, Security Credential, passwords, PINs or OTPs in `index.html`, screenshots, GitHub, public files, or chat.

## Important
This is a sandbox/demo scaffold. Real-money operation requires proper authentication, a database/ledger, idempotency, audit logs, secure secret storage, HTTPS, monitoring, fraud/risk controls, and all required Kenyan regulatory/business approvals.
